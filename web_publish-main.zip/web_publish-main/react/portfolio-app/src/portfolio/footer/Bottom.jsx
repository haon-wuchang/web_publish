import React from 'react';

export default function Bottom() {
    return (
        <>
         <p>Dream Software Engineer HAON - All right reserved</p>
        </>
    );
}

