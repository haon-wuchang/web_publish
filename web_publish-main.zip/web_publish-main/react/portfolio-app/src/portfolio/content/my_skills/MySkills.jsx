import React from 'react';


export default function MySkills({children}) {

    return (
            <div className="skills">
                {children}
            </div>
    );
}

