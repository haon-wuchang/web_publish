import  './App.css';
import AppCgv from './components/cgv_layout/AppCgv.jsx';

export default function App() {
  return (
    <div className="App">
        <AppCgv></AppCgv>
    </div>
  );  
}



