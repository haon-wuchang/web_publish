import './App.css';
import AppMenu from './components/AppMenu.jsx';


export default function App() {
  return (
    <div className="App">
        <AppMenu></AppMenu>
    </div>
  );  
}



