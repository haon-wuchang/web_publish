
export default function Footer({children}) {
    return(
        <footer style={{backgroundColor : 'lightsteelblue'}}>
            {children}
        </footer>
    );
}