
export default function Body({children}) {
    return(
        <div className="content"> 
            {children}
        </div>
    );
}