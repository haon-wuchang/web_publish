
import '../css/Avatar.css';

export default function AvatarImage({img}) {
    return (
        <img src={img} className="avatar-img"></img>
    );
}