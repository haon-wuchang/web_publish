
export default function HeaderBottomSearch() {
    return(
        <>
            <div class="header-bottom-search">
                <input type="search" value="리틀 엠마" />
                    <i class="fa-solid fa-magnifying-glass"></i>
            </div>
        </>
    );
}