
export default function FooterContentTop({src}) {
    return(
        <div class="footer-content-top">
            <div class="footer-content">
                <img src={src} alt="" />
            </div>
        </div>
    );
}