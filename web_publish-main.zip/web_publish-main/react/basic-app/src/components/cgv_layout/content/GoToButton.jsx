
export default function GoToButton() {
    return(
        <div  class="back-to-top"> 
            <a href="#"><img src="https://img.cgv.co.kr/R2014/images/common/btn/gotoTop.png" alt="" /></a>
        </div>
    );
}