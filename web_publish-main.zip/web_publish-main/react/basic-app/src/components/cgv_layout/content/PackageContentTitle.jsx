
export default function PackageContentTitle({title}) {
    return(
            <div>
                <span className="package">{title}</span>
                <button className="total-view-button-2">더보기</button>
            </div>
    );
}