
export default function MovieChartContent() {
    return(
        <h3>KOBIS & KMDB API 연동</h3>
    );
}