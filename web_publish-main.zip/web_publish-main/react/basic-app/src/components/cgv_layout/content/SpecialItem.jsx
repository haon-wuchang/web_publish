
export default function SpecialItem({title, intro}) {
    return(
        <>
            <span>{title}</span>
            <span>{intro}</span>
        </>
    );
}