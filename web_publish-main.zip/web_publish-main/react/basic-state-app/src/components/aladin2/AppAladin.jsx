import './aladin.css';
import MenuList from './MenuList.jsx'

export default function AppAladin() {
    return (
        <div>
            <MenuList />
        </div>
    );
}

