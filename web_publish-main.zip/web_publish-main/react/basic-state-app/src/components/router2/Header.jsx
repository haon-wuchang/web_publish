import React from 'react';

export default function Header({children}) {
    return (
        <div>
            {children}
        </div>
    );
}

