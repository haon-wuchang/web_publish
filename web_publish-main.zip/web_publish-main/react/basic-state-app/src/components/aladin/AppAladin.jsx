import React from 'react';
import BookList from './BookList.jsx';
import './aladin.css';
export default function AppAladin() {
    return (
        <div className='box'>
            <BookList />
        </div>
    );
}

