import React from 'react';

export default function About() {
    return (
        <div>
            <h1>About</h1>
        </div>
    );
}

