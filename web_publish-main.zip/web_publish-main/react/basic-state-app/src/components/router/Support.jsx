import React from 'react';

export default function Support() {
    return (
        <div>
            <h1>Suporrt</h1>
        </div>
    );
}

