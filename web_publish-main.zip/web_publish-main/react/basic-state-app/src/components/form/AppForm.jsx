import React from 'react';
import UserInfo from './UserInfo.jsx';
import Login from './Login.jsx';
import Login2 from './Login2.jsx';
import CgvLoginForm from './CgvLoginForm.jsx';
import Signup from './Signup.jsx';
import TestJoin from './TestJoin.jsx';
import Signup2 from './Signup2.jsx';

export default function AppForm() {
    return (
        <div>
            {/* <Login />
            <hr />
            <UserInfo /> */}
            {/* <CgvLoginForm /> */}
            {/* <TestJoin /> */}
            {/* <Signup2 /> */}
            {/* <Login2 /> */}
            <Signup /> 
        </div>
    );
}


