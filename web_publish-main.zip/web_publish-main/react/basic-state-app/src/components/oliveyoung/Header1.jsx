
export default function Header1({children}) {
    return (
        <header>
            {children}
        </header>
    );
}


