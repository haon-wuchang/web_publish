import BookList from './Booklist.jsx'
import './aladin.css';

export default function AppAladin() {
    return(
        <BookList />
    );
}