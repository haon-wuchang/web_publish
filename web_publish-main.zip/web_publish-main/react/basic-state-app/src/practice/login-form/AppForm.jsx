import React from 'react';
import Form from './Form.jsx';

export default function AppForm() {
    return (
        <div>   
            <Form />
        </div>
    );
}

