import React from 'react';

export default function BestBookContent() {
    return (
        <div className='q'>
            
        </div>
    );
}

