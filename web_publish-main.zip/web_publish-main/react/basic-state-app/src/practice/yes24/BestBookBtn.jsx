import React from 'react';

export default function BestBookBtn() {
    return (
        <div className='d'>
            <div>
                <input type="radio" />
                <button>-</button>
                <span>1</span>
                <button>+</button>
            </div>
            <div>
                <button>카트에 넣기</button>
                <button>바로구매</button>
                <button>리스트에 넣기</button>
            </div>
        </div>
    );
}

