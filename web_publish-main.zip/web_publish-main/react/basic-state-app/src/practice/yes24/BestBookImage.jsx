import React from 'react';

export default function BestBookImage() {
    return (
        <div>
            <div className='aa'>
                <span className='span1'>1</span>
                    <img className='e' src="https://image.yes24.com/goods/13137546/L" alt="이미지" />
            </div>
        <button>미리보기</button>
        </div>
    );
}

