//사칙연산   이케5가지는 기억해둬

console.log(3+2);
console.log(3-2);
console.log(3*2);
console.log(3/2);
console.log(3%2); //3을2로나눈 나머지값
console.log(3**2);  // 3의 2제곱



let a = 100; //a 가짝수인지 홀수인지 궁금하다
console.log(a % 2); 


console.log(10+20); //사칙연산자
console.log("sum : "+10+20); //접합연산자


console.log("sum : "+(10+20)); 
console.log(`sum : ${10+20}`); //==> 템플릿리터럴 방식