//선언문과 표현식(expressions)에 대한 차이

let a;   //==>선언문  let 은 선언자 a는 변수
let b=100; //==>표현식    b는 100이라는 값을 화면에 표현해서 표현식임
let c=''; //==> 표현식임 빈공간이라는 값이 잇는거임
let d =undefined; //==>선언문 d 변수를 선언하는데 값은 아직 없어용
let e=null; //선언문

console.log(a);  //값이 없어서 undefined 가 나온거임 
console.log(b);
console.log(c); //c는 공백이라는 값이 잇어서 undefined이 아니라 공백으로 값이나옴
console.log(d);
console.log(e);


