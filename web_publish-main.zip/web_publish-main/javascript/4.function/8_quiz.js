import {singleGugudan, selectGugudan, fruitsTower} from'./f2module_arrow.js';

//3단출력 7~9단 출력 전체출력(1~9단)
singleGugudan(3);
selectGugudan(7,9);
// gugudan();
fruitsTower(`🍑`,7);

