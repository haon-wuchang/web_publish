//1부터 6까지 출력
//row=3인경우 for문을 빠져나오기

for(let row=1;row<7;row++){
    if(row===3){
        // break;
        row=10;
    }
    else {
        console.log(`row=${row}`);
    }
    
}


