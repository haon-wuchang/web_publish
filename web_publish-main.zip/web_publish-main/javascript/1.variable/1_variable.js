
let name = '삐묵' ;  
let age = 20;
const address ='서울시'


name = '필릭스'
age='서울';
age=30;

console.log(name);
console.log(age);
console.log(address);
