/

let a=100;
a=10;
a=true;
a=10.45;
a='javascript';

console.log(a);

const AA=100;
AA=10;
AA='css'; 

console.log(AA);


