//object : array(=배열)[], JSON {}
let apple = null ;
apple = {
    name:'apple',
    color:'red',
    display:'🍎'
} ;

console.log(apple); 


console.log(apple.name); 
console.log(apple.color); 
console.log(apple.display); 

//orange json 객체 생성 후 결과 출력해주세요

let orange = {
    name:'orange',
    color:'orange',
    display: '🍊'
};

console.log(orange);
console.log(orange.name);
console.log(orange.color);
console.log(orange.display);  



//1~5까지 출력
let numberList = [
    1,2,3,4,5  
];
console.log(numberList);
console.log(numberList[0]);
console.log(numberList[4]);
console.log(numberList[5]);  




