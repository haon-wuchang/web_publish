
// 정수형 변수 선언 
let number = 100;
number = 100.1 ; 
console.log(number);


// 실수형 변수 선언
let fnumber =10.234;
fnumber = 200; /**let 이라 첨에 실수 넣고 낟중에 데이터값을 정수로 바꿔도 출력이 된다 */
console.log(fnumber);


// 불린형 변수 선언
let flag=true;  //  !(=not) !는 반댓값으로 전환할떄 사용
let =!true;
// let =!true;  =  let flagTest=!flag;  같은 의미임
let flagTest=!flag;  



// 객체형 변수 선언
let nameList = ['필리스','리노','아이엔'];
console.log(nameList);

let address = undefined; 


let addressList = null;


let x = 10;  //숫자
let xx = 10;//숫자
let y = '10'; //문자
let obj = {name:'삐뮥'};

console.log(x, typeof x);
console.log(xx, typeof xx);
console.log(y, typeof y);
console.log(obj, typeof obj);

console.log(x == y);  
console.log(x === xx);  
console.log(x === y);  


